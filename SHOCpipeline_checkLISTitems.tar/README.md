SHOCpipeline
============

Data reduction pipeline for SHOC